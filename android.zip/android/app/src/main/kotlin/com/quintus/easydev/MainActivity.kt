package com.quintus.dev

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
