import 'package:flutter/material.dart';

class AppColors {
  static const Color bottomNavBackground = Colors.white;
}
