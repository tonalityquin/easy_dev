class OfflineTtsFilters {
  static bool enabled = true;

  static bool parkingRequest = true;
  static bool departureRequest = true;
  static bool departureCompleted = true;
}
