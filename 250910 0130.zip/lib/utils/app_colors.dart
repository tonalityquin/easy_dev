import 'package:flutter/material.dart';

class AppColors {
  static const Color selectedItemColor = Color(0xFF42A5F5);
  static const Color unselectedItemColor = Colors.white;
  static const Color bodyBackground = Color(0xFF4E4D4D);
  static const Color bottomNavBackground = Colors.white;
}
