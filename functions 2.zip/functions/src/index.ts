import * as admin from "firebase-admin";
import * as functions from "firebase-functions";

admin.initializeApp();
const db = admin.firestore();

// ⚙️ 필요시 리전 변경 (서울: asia-northeast3)
const REGION = "asia-northeast3";

// 카운트 대상 type (요구사항에 맞춰 확장 가능)
const TARGET_TYPE = "parking_completed";

// plates 문서에서 필요한 필드만 추출
type PlateDoc = {
  area?: string;
  location?: string;     // 단일/복합 모두 최종 위치 문자열(예: 'A-1', 'Parent - Child')
  type?: string;         // 예: 'parking_completed'
  // parent?: string;    // 필요시 부모 합계도 증감하려면 주석 해제/사용
};

// 증감 연산 단위
type DeltaOp = { area: string; type: string; location: string; delta: number };

// 안전 추출
function extract(d: FirebaseFirestore.DocumentData | undefined | null): PlateDoc | null {
  if (!d) return null;
  return {
    area: typeof d.area === "string" ? d.area : undefined,
    location: typeof d.location === "string" ? d.location : undefined,
    type: typeof d.type === "string" ? d.type : undefined,
    // parent: typeof d.parent === "string" ? d.parent : undefined,
  };
}

// before/after로부터 증감 리스트를 뽑아냅니다.
function computeDeltas(before: PlateDoc | null, after: PlateDoc | null): DeltaOp[] {
  const ops: DeltaOp[] = [];

  // 이전 문서가 집계 대상이라면 -1
  if (before?.area && before?.location && before?.type === TARGET_TYPE) {
    ops.push({ area: before.area, type: TARGET_TYPE, location: before.location, delta: -1 });
  }

  // 이후 문서가 집계 대상이라면 +1
  if (after?.area && after?.location && after?.type === TARGET_TYPE) {
    ops.push({ area: after.area, type: TARGET_TYPE, location: after.location, delta: +1 });
  }

  // 같은 키로 -1, +1이 동시에 들어온 경우(의미 없는 변경)는 합산으로 상쇄
  // 키: area|type|location
  const merged = new Map<string, number>();
  for (const op of ops) {
    const k = `${op.area}|${op.type}|${op.location}`;
    merged.set(k, (merged.get(k) ?? 0) + op.delta);
  }

  const result: DeltaOp[] = [];
  for (const [k, v] of merged.entries()) {
    if (v === 0) continue; // 상쇄
    const [area, type, location] = k.split("|");
    result.push({ area, type, location, delta: v });
  }

  return result;
}

/**
 * areas/{area}/locationCounts/{type} 문서의 counts 맵을 증감(increment)합니다.
 * counts[location] += delta
 */
async function applyDeltas(ops: DeltaOp[]): Promise<void> {
  if (ops.length === 0) return;

  // (area,type) 단위로 묶어서 각 문서를 한 번만 set하도록 그룹핑
  const groups = new Map<string, DeltaOp[]>();
  for (const op of ops) {
    const k = `${op.area}|${op.type}`;
    const arr = groups.get(k) ?? [];
    arr.push(op);
    groups.set(k, arr);
  }

  // 하나의 트랜잭션으로 모든 그룹을 처리
  await db.runTransaction(async (tx) => {
    for (const [k, arr] of groups.entries()) {
      const [area, type] = k.split("|");
      const ref = db.doc(`areas/${area}/locationCounts/${type}`);

      // counts 패치 생성
      const countsPatch: Record<string, admin.firestore.FieldValue> = {};
      for (const { location, delta } of arr) {
        countsPatch[location] = admin.firestore.FieldValue.increment(delta);
      }

      tx.set(
        ref,
        {
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
          counts: countsPatch,
        },
        { merge: true },
      );
    }
  });
}

/**
 * plates/{id} onWrite:
 *  - 생성: after(type==TARGET_TYPE) → +1
 *  - 삭제: before(type==TARGET_TYPE) → -1
 *  - 수정: before/after 비교 후 delta 계산(이동/타입변경/지역변경 모두 처리)
 */
export const onPlatesWrite = functions
  .region(REGION)
  .firestore.document("plates/{id}")
  .onWrite(async (change, context) => {
    const before = extract(change.before.exists ? (change.before.data() as PlateDoc) : null);
    const after  = extract(change.after.exists  ? (change.after.data()  as PlateDoc) : null);

    const ops = computeDeltas(before, after);

    // 아무 변경도 없다면 종료
    if (ops.length === 0) return;

    try {
      await applyDeltas(ops);
    } catch (e) {
      // functions 로그에만 남김
      console.error("[onPlatesWrite] applyDeltas failed", {
        eventId: context.eventId,
        ops,
        error: (e as Error)?.message ?? e,
      });
      // 일시 장애 시 재시도는 플랫폼이 담당
      throw e;
    }
  });

/**
 * (선택) 부모 합계까지 유지하려면:
 * - PlateDoc에 parent 필드를 사용
 * - computeDeltas에서 parent 키에 대해 별도 DeltaOp를 추가하고
 * - applyDeltas에서 counts 대신 parents 맵(예: parents[parentName])을 증감
 * - 혹은 동일 문서 내 다른 맵 필드로 함께 증감 처리 가능
 *
 * 예시:
 *   ops.push({ area, type: TARGET_TYPE, location: `__PARENT__:${parent}`, delta: ±1 })
 *   => applyDeltas에서 location prefix를 판별해 parents 맵에 증감
 */
