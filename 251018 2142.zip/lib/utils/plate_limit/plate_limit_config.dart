class PlateLimitConfig {
  static const int min = 0;
  static const int max = 50;
  static const int defaultLimit = 5; // ← 앞으로 여기만 수정


  static const String prefsKey = 'plateListLimit';
}



