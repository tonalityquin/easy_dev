import 'package:flutter/material.dart';

class AppNavigator {
  AppNavigator._();
  static final key = GlobalKey<NavigatorState>();
}
