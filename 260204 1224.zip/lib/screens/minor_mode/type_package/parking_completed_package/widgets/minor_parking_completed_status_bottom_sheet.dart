import 'dart:convert';
import 'dart:math' as math;

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../../../models/location_model.dart';
import '../../../../../models/plate_model.dart';

import '../../../../../states/area/area_state.dart';
import '../../../../../states/location/location_state.dart';
import '../../../../../states/plate/minor_plate_state.dart';
import '../../../../../states/plate/movement_plate.dart';
import '../../../../../states/user/user_state.dart';
import '../../../../../enums/plate_type.dart';

import '../../../../../repositories/plate_repo_services/plate_repository.dart';
import '../../../../../utils/snackbar_helper.dart';
import '../../../../../widgets/dialog/billing_bottom_sheet/billing_bottom_sheet.dart';
import '../../../../../widgets/dialog/confirm_cancel_fee_dialog.dart';

import '../../../../common_package/log_package/log_viewer_bottom_sheet.dart';
import '../../../modify_package/minor_modify_plate_screen.dart';

/// ✅ 브랜딩(ColorScheme) 기반 톤 유틸
class _BrandTone {
  static Color border(ColorScheme cs) => cs.outlineVariant.withOpacity(0.85);
  static Color softBorder(ColorScheme cs) => cs.outlineVariant.withOpacity(0.55);

  static Color danger(ColorScheme cs) => cs.error;
  static Color dangerBg(ColorScheme cs) => cs.errorContainer;
  static Color dangerFg(ColorScheme cs) => cs.onErrorContainer;

  static Color ok(ColorScheme cs) => cs.tertiary;
  static Color okBg(ColorScheme cs) => cs.tertiaryContainer;

  static Color warning(ColorScheme cs) => cs.secondary;
  static Color warningBg(ColorScheme cs) => cs.secondaryContainer;
  static Color warningFg(ColorScheme cs) => cs.onSecondaryContainer;
}

/// ✅ 추가: 다이얼로그/테이블에서 “콜백 없이” 바로 열기 위한 wrapper
/// - 기존 showMinorParkingCompletedStatusBottomSheet 시그니처(콜백 required)는 유지
Future<void> showMinorParkingCompletedStatusBottomSheetFromDialog({
  required BuildContext context,
  required PlateModel plate,
}) async {
  await showMinorParkingCompletedStatusBottomSheet(
    context: context,
    plate: plate,
    onRequestEntry: () async {
      final area = context.read<AreaState>().currentArea;
      await handleEntryParkingRequest(context, plate.plateNumber, area);
    },
    onDelete: () {
      // 테이블 상세 → 작업 수행 경로에서는 삭제를 기본 비활성화(더블/트리플 동일 정책)
      try {
        showFailedSnackbar(context, '이 경로에서는 삭제 기능을 사용할 수 없습니다.');
      } catch (_) {
        ScaffoldMessenger.maybeOf(context)?.showSnackBar(
          const SnackBar(content: Text('이 경로에서는 삭제 기능을 사용할 수 없습니다.')),
        );
      }
    },
  );
}

Future<void> showMinorParkingCompletedStatusBottomSheet({
  required BuildContext context,
  required PlateModel plate,
  required Future<void> Function() onRequestEntry,
  required VoidCallback onDelete,
}) async {
  final plateNumber = plate.plateNumber;
  final division = context.read<UserState>().division;
  final area = context.read<AreaState>().currentArea;

  await showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    useSafeArea: true,
    backgroundColor: Colors.transparent,
    builder: (_) => FractionallySizedBox(
      heightFactor: 1,
      child: _FullHeightSheet(
        plate: plate,
        plateNumber: plateNumber,
        division: division,
        area: area,
        onRequestEntry: onRequestEntry,
        onDelete: onDelete,
      ),
    ),
  );
}

enum _DepartureOverrideChoice { proceed, goBilling, cancel }
enum _DrivingResult { completed, cancelled, failed }

class _FullHeightSheet extends StatefulWidget {
  const _FullHeightSheet({
    required this.plate,
    required this.plateNumber,
    required this.division,
    required this.area,
    required this.onRequestEntry,
    required this.onDelete,
  });

  final PlateModel plate;
  final String plateNumber;
  final String division;
  final String area;
  final Future<void> Function() onRequestEntry;
  final VoidCallback onDelete;

  @override
  State<_FullHeightSheet> createState() => _FullHeightSheetState();
}

class _FullHeightSheetState extends State<_FullHeightSheet>
    with SingleTickerProviderStateMixin {
  late PlateModel _plate;

  final ScrollController _scrollController = ScrollController();

  late final AnimationController _attentionCtrl;
  late final Animation<double> _attentionPulse;

  bool _departureOverrideArmed = false;
  DateTime? _departureOverrideArmedAt;
  static const Duration _overrideWindow = Duration(seconds: 12);

  bool _primaryBusy = false;

  @override
  void initState() {
    super.initState();
    _plate = widget.plate;

    _attentionCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 820),
    );

    _attentionPulse = TweenSequence<double>([
      TweenSequenceItem(
        tween: Tween<double>(begin: 0, end: 1)
            .chain(CurveTween(curve: Curves.easeOutCubic)),
        weight: 45,
      ),
      TweenSequenceItem(
        tween: Tween<double>(begin: 1, end: 0)
            .chain(CurveTween(curve: Curves.easeInCubic)),
        weight: 55,
      ),
    ]).animate(_attentionCtrl);
  }

  @override
  void dispose() {
    _scrollController.dispose();
    _attentionCtrl.dispose();
    super.dispose();
  }

  PlateType? get _type => _plate.typeEnum;

  bool get _needsBilling =>
      (_type == PlateType.parkingCompleted) && (_plate.isLockedFee != true);

  bool get _isFreeBilling =>
      (_plate.basicAmount ?? 0) == 0 && (_plate.addAmount ?? 0) == 0;

  /// ✅ 앱 강제 종료/재실행 등으로 '주행 중(선점)' 상태가 남아있을 때,
  /// 동일 사용자가 다시 진입하면 UI 문구를 '시작'이 아닌 '계속'으로 노출합니다.
  bool get _isMyDriving {
    final userName = (context.read<UserState>().name).trim();
    final selectedBy = (_plate.selectedBy ?? '').trim();
    final t = _type;
    return _plate.isSelected == true &&
        userName.isNotEmpty &&
        selectedBy.isNotEmpty &&
        selectedBy == userName &&
        (t == PlateType.parkingRequests || t == PlateType.departureRequests);
  }

  bool get _overrideActive {
    if (!_departureOverrideArmed || _departureOverrideArmedAt == null) {
      return false;
    }
    return DateTime.now().difference(_departureOverrideArmedAt!) <=
        _overrideWindow;
  }

  void _resetOverride() {
    _departureOverrideArmed = false;
    _departureOverrideArmedAt = null;
  }

  void _armOverride() {
    _departureOverrideArmed = true;
    _departureOverrideArmedAt = DateTime.now();
  }

  String _plateDocId() {
    if (_plate.id.trim().isNotEmpty) return _plate.id.trim();
    return '${_plate.plateNumber}_${_plate.area}';
  }

  String get _effectiveLocation =>
      _plate.location.trim().isEmpty ? '미지정' : _plate.location.trim();

  Future<void> _runPrimary(Future<void> Function() fn) async {
    if (_primaryBusy) return;
    setState(() => _primaryBusy = true);
    try {
      await fn();
    } finally {
      if (mounted) setState(() => _primaryBusy = false);
    }
  }

  void _showWarningSafe(String message) {
    try {
      showFailedSnackbar(context, message);
      return;
    } catch (_) {}

    final messenger = ScaffoldMessenger.maybeOf(context);
    if (messenger != null) {
      messenger.showSnackBar(SnackBar(content: Text(message)));
      return;
    }

    final nav = Navigator.of(context, rootNavigator: true);
    final messenger2 = ScaffoldMessenger.maybeOf(nav.context);
    if (messenger2 != null) {
      messenger2.showSnackBar(SnackBar(content: Text(message)));
      return;
    }

    showDialog<void>(
      context: nav.context,
      builder: (_) => AlertDialog(
        title: const Text('안내'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(nav.context).pop(),
            child: const Text('확인'),
          ),
        ],
      ),
    );
  }

  Future<void> _triggerBillingRequiredAttention({
    required String message,
  }) async {
    _showWarningSafe(message);

    if (_scrollController.hasClients) {
      await _scrollController.animateTo(
        0,
        duration: const Duration(milliseconds: 320),
        curve: Curves.easeOut,
      );
    }

    _attentionCtrl.forward(from: 0);
  }

  Future<bool> _autoPrebillFreeIfNeeded() async {
    if (_plate.isLockedFee == true) return true;
    if (!_isFreeBilling) return false;

    final userName = context.read<UserState>().name;
    final repo = context.read<PlateRepository>();
    final plateState = context.read<MinorPlateState>();
    final firestore = FirebaseFirestore.instance;

    final now = DateTime.now();
    final currentTime = now.toUtc().millisecondsSinceEpoch ~/ 1000;

    final updatedPlate = _plate.copyWith(
      isLockedFee: true,
      lockedAtTimeInSeconds: currentTime,
      lockedFeeAmount: 0,
      paymentMethod: '무료',
    );

    try {
      await repo.addOrUpdatePlate(_plate.id, updatedPlate);
      _reportDbSafe(
        area: _plate.area,
        action: 'write',
        source: 'parkingCompletedStatus.freeAutoPrebill.repo.addOrUpdatePlate',
        n: 1,
      );

      await plateState.minorUpdatePlateLocally(
        PlateType.parkingCompleted,
        updatedPlate,
      );

      final log = {
        'action': '무료 자동 정산',
        'performedBy': userName,
        'timestamp': now.toIso8601String(),
        'lockedFee': 0,
        'paymentMethod': '무료',
      };

      await firestore.collection('plates').doc(_plate.id).update({
        'logs': FieldValue.arrayUnion([log]),
      });
      _reportDbSafe(
        area: _plate.area,
        action: 'write',
        source:
        'parkingCompletedStatus.freeAutoPrebill.plates.update.logs.arrayUnion',
        n: 1,
      );

      if (!mounted) return false;
      setState(() => _plate = updatedPlate);

      _resetOverride();
      return true;
    } catch (e) {
      if (!mounted) return false;
      _showWarningSafe('무료 자동 정산 중 오류가 발생했습니다: $e');
      return false;
    }
  }

  Future<_DepartureOverrideChoice?> _showDepartureOverrideDialog() async {
    final cs = Theme.of(context).colorScheme;

    return showDialog<_DepartureOverrideChoice>(
      context: context,
      barrierDismissible: true,
      barrierColor: cs.scrim.withOpacity(0.55),
      builder: (_) {
        return Dialog(
          insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Container(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
            decoration: BoxDecoration(
              color: cs.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _BrandTone.border(cs)),
              boxShadow: [
                BoxShadow(
                  color: cs.shadow.withOpacity(0.18),
                  blurRadius: 24,
                  offset: const Offset(0, 12),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: _BrandTone.warningBg(cs).withOpacity(0.55),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: _BrandTone.warning(cs).withOpacity(0.30),
                        ),
                      ),
                      child: Icon(
                        Icons.warning_amber_rounded,
                        color: _BrandTone.warning(cs),
                        size: 20,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        '정산 없이 출차 요청',
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 16,
                          color: cs.onSurface,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding:
                  const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: cs.surfaceContainerLow,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _BrandTone.softBorder(cs)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '현재 사전 정산이 되어있지 않습니다.',
                        style: TextStyle(
                          color: cs.onSurface,
                          fontWeight: FontWeight.w900,
                          fontSize: 13,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        '그래도 출차 요청으로 이동하시겠습니까?',
                        style: TextStyle(
                          color: cs.onSurfaceVariant,
                          fontWeight: FontWeight.w700,
                          fontSize: 12,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 8),
                        decoration: BoxDecoration(
                          color: _BrandTone.warningBg(cs).withOpacity(0.55),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: _BrandTone.warning(cs).withOpacity(0.30)),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.directions_car_filled,
                                size: 16, color: _BrandTone.warning(cs)),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                '차량: ${_plate.plateNumber}',
                                style: TextStyle(
                                  color: _BrandTone.warningFg(cs),
                                  fontWeight: FontWeight.w900,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    OutlinedButton(
                      onPressed: () => Navigator.pop(
                          context, _DepartureOverrideChoice.cancel),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: cs.onSurface,
                        side: BorderSide(color: _BrandTone.border(cs)),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 12),
                      ),
                      child: const Text('취소',
                          style: TextStyle(fontWeight: FontWeight.w900)),
                    ),
                    const SizedBox(width: 10),
                    OutlinedButton(
                      onPressed: () => Navigator.pop(
                          context, _DepartureOverrideChoice.goBilling),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: cs.primary,
                        side: BorderSide(color: cs.primary.withOpacity(0.35)),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 12),
                        backgroundColor: cs.primary.withOpacity(0.06),
                      ),
                      child: const Text('정산하기',
                          style: TextStyle(fontWeight: FontWeight.w900)),
                    ),
                    const SizedBox(width: 10),
                    FilledButton(
                      onPressed: () => Navigator.pop(
                          context, _DepartureOverrideChoice.proceed),
                      style: FilledButton.styleFrom(
                        backgroundColor: _BrandTone.warning(cs),
                        foregroundColor: _BrandTone.warningFg(cs),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 14, vertical: 12),
                      ),
                      child: const Text('그래도 출차 요청',
                          style: TextStyle(fontWeight: FontWeight.w900)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _goDepartureRequested() async {
    final movementPlate = context.read<MovementPlate>();

    await movementPlate.setDepartureRequested(
      _plate.plateNumber,
      _plate.area,
      _effectiveLocation,
    );

    if (!mounted) return;
    Navigator.pop(context);
  }

  Future<void> _logDrivingCancel({
    required String plateId,
    required String phase,
    required String userName,
  }) async {
    final firestore = FirebaseFirestore.instance;
    final now = DateTime.now();
    final cancelLog = {
      'action': '주행 취소',
      'performedBy': userName,
      'timestamp': now.toIso8601String(),
      'phase': phase,
    };

    await firestore.collection('plates').doc(plateId).update({
      'logs': FieldValue.arrayUnion([cancelLog]),
    });
  }

  Future<_DrivingResult> _showDrivingBlockingDialog({
    required String message,
    required bool canCancel,
    required String cancelDisabledHint,
    required Future<void> Function() onComplete,
    required Future<void> Function() onCancel,
  }) async {
    Object? err;
    StackTrace? st;

    final cs = Theme.of(context).colorScheme;

    final result = await showDialog<_DrivingResult>(
      context: context,
      useRootNavigator: true,
      barrierDismissible: false,
      barrierColor: cs.scrim.withOpacity(0.65),
      builder: (_) => PopScope(
        canPop: false,
        child: _DrivingBlockingDialog(
          message: message,
          canCancel: canCancel,
          cancelDisabledHint: cancelDisabledHint,
          onComplete: () async {
            try {
              await onComplete();
              return _DrivingResult.completed;
            } catch (e, s) {
              err = e;
              st = s;
              return _DrivingResult.failed;
            }
          },
          onCancel: () async {
            try {
              await onCancel();
              return _DrivingResult.cancelled;
            } catch (e, s) {
              err = e;
              st = s;
              return _DrivingResult.failed;
            }
          },
        ),
      ),
    );

    final r = result ?? _DrivingResult.failed;
    if (r == _DrivingResult.failed && err != null) {
      _showWarningSafe('주행 처리 실패: $err');
      // ignore: unused_local_variable
      final _ = st;
    }
    return r;
  }

  // ─────────────────────────────────────────
  // ✅ 입차 완료: “주차 구역 선택” (캐시 기반)
  // ─────────────────────────────────────────

  String _resolveAreaForCache() {
    final a = _plate.area.trim();
    if (a.isNotEmpty) return a;

    final wa = widget.area.trim();
    if (wa.isNotEmpty) return wa;

    return context.read<AreaState>().currentArea.trim();
  }

  String _locationDisplayName(LocationModel loc) {
    final t = (loc.type ?? '').trim();
    final parent = (loc.parent ?? '').trim();
    final name = loc.locationName.trim();

    if (t == 'composite' && parent.isNotEmpty && name.isNotEmpty) {
      return '$parent - $name';
    }
    return name.isNotEmpty ? name : '미지정';
  }

  Future<List<LocationModel>> _loadCachedLocationsForArea(String area) async {
    // 1) LocationState 우선
    try {
      final ls = context.read<LocationState>();
      final list = ls.locations;
      if (list.isNotEmpty) return List<LocationModel>.of(list);
    } catch (_) {}

    // 2) SharedPreferences fallback
    try {
      final prefs = await SharedPreferences.getInstance();
      final cachedJson = prefs.getString('cached_locations_$area');
      if (cachedJson == null || cachedJson.trim().isEmpty) return [];

      final decoded = json.decode(cachedJson);
      if (decoded is! List) return [];

      return decoded
          .map(
            (e) => LocationModel.fromCacheMap(
          Map<String, dynamic>.from(e as Map<dynamic, dynamic>),
        ),
      )
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<String?> _showParkingLocationPickerDialog({
    required String plateNumber,
    required String area,
    required Future<void> Function(String pickedLocation) onConfirm,
  }) async {
    final cs = Theme.of(context).colorScheme;
    final rootContext = Navigator.of(context, rootNavigator: true).context;

    final cached = await _loadCachedLocationsForArea(area);
    final items = cached
        .where((e) => e.locationName.trim().isNotEmpty)
        .toList()
      ..sort(
            (a, b) => _locationDisplayName(a)
            .toLowerCase()
            .compareTo(_locationDisplayName(b).toLowerCase()),
      );

    if (items.isEmpty) {
      _showWarningSafe(
        '저장된 주차 구역(캐시)이 없습니다.\n'
            '설정/개발 메뉴에서 “주차 구역 수동 새로고침” 후 다시 시도해주세요.',
      );
      return null;
    }

    return showDialog<String>(
      context: rootContext,
      barrierDismissible: false,
      barrierColor: cs.scrim.withOpacity(0.65),
      builder: (_) {
        String query = '';
        String? selectedName; // ✅ LocationModel.id 등 미확실 필드에 의존하지 않음
        bool saving = false;
        String? errorText;

        return StatefulBuilder(
          builder: (dialogCtx, setDialogState) {
            final filtered = items.where((loc) {
              final q = query.trim().toLowerCase();
              if (q.isEmpty) return true;
              final dn = _locationDisplayName(loc).toLowerCase();
              return dn.contains(q);
            }).toList();

            return Dialog(
              backgroundColor: cs.surface,
              surfaceTintColor: Colors.transparent,
              elevation: 10,
              insetPadding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18),
                side: BorderSide(color: _BrandTone.border(cs)),
              ),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 14),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Header
                    Row(
                      children: [
                        Container(
                          width: 36,
                          height: 36,
                          decoration: BoxDecoration(
                            color: cs.primary.withOpacity(0.10),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: cs.primary.withOpacity(0.25),
                            ),
                          ),
                          child: Icon(
                            Icons.local_parking_rounded,
                            color: cs.primary,
                            size: 20,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            '주차 구역 선택',
                            style: TextStyle(
                              fontWeight: FontWeight.w900,
                              fontSize: 16,
                              color: cs.onSurface,
                            ),
                          ),
                        ),
                        IconButton(
                          tooltip: '닫기',
                          onPressed: saving
                              ? null
                              : () => Navigator.of(dialogCtx).pop(),
                          icon: Icon(Icons.close, color: cs.onSurfaceVariant),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),

                    // Info
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 10),
                      decoration: BoxDecoration(
                        color: cs.surfaceContainerLow,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _BrandTone.softBorder(cs)),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.directions_car_filled,
                              size: 16, color: cs.onSurfaceVariant),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              '차량: $plateNumber  •  지역: $area',
                              style: TextStyle(
                                color: cs.onSurface,
                                fontWeight: FontWeight.w800,
                                fontSize: 12,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 12),

                    // Search
                    TextField(
                      enabled: !saving,
                      onChanged: (v) => setDialogState(() => query = v),
                      decoration: InputDecoration(
                        hintText: '주차 구역 검색',
                        prefixIcon: Icon(Icons.search, color: cs.onSurfaceVariant),
                        isDense: true,
                        filled: true,
                        fillColor: cs.surfaceContainerLow,
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 10),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide(color: _BrandTone.border(cs)),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide(color: _BrandTone.border(cs)),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(14),
                          borderSide: BorderSide(color: cs.primary.withOpacity(0.70)),
                        ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    // List
                    Container(
                      constraints: const BoxConstraints(maxHeight: 360),
                      decoration: BoxDecoration(
                        color: cs.surface,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _BrandTone.border(cs)),
                      ),
                      child: filtered.isEmpty
                          ? Padding(
                        padding: const EdgeInsets.all(14),
                        child: Row(
                          children: [
                            Icon(Icons.info_outline,
                                color: cs.onSurfaceVariant),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                '검색 결과가 없습니다.',
                                style: TextStyle(
                                  color: cs.onSurfaceVariant,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                          : ListView.separated(
                        shrinkWrap: true,
                        itemCount: filtered.length,
                        separatorBuilder: (_, __) => Divider(
                          height: 1,
                          color: cs.outlineVariant.withOpacity(0.40),
                        ),
                        itemBuilder: (_, i) {
                          final loc = filtered[i];
                          final displayName = _locationDisplayName(loc);
                          final cap = loc.capacity;

                          return RadioListTile<String>(
                            value: displayName,
                            groupValue: selectedName,
                            onChanged: saving
                                ? null
                                : (v) => setDialogState(() {
                              selectedName = v;
                              errorText = null;
                            }),
                            title: Text(
                              displayName,
                              style: TextStyle(
                                fontWeight: FontWeight.w900,
                                fontSize: 13,
                                color: cs.onSurface,
                              ),
                            ),
                            subtitle: Text(
                              'capacity: $cap',
                              style: TextStyle(
                                color: cs.onSurfaceVariant,
                                fontWeight: FontWeight.w700,
                                fontSize: 12,
                              ),
                            ),
                            dense: true,
                            controlAffinity:
                            ListTileControlAffinity.trailing,
                            activeColor: cs.primary,
                          );
                        },
                      ),
                    ),

                    if (errorText != null) ...[
                      const SizedBox(height: 10),
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 8),
                        decoration: BoxDecoration(
                          color: _BrandTone.dangerBg(cs).withOpacity(0.55),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: _BrandTone.danger(cs).withOpacity(0.25)),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.error_outline,
                                size: 18, color: _BrandTone.danger(cs)),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                errorText!,
                                style: TextStyle(
                                  color: _BrandTone.dangerFg(cs),
                                  fontWeight: FontWeight.w800,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],

                    const SizedBox(height: 14),

                    // Actions
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: saving
                                ? null
                                : () => Navigator.of(dialogCtx).pop(),
                            style: OutlinedButton.styleFrom(
                              foregroundColor: cs.onSurface,
                              side: BorderSide(color: _BrandTone.border(cs)),
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12)),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 12),
                              textStyle: const TextStyle(
                                  fontSize: 14, fontWeight: FontWeight.w900),
                            ),
                            child: Text(saving ? '처리 중...' : '취소'),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: FilledButton(
                            onPressed: (saving || selectedName == null)
                                ? null
                                : () async {
                              final pickedName = selectedName!.trim();
                              if (pickedName.isEmpty) return;

                              setDialogState(() {
                                saving = true;
                                errorText = null;
                              });

                              try {
                                await onConfirm(pickedName);
                                if (!dialogCtx.mounted) return;
                                Navigator.of(dialogCtx).pop(pickedName);
                              } catch (e) {
                                setDialogState(() {
                                  saving = false;
                                  errorText = '저장 중 오류가 발생했습니다: $e';
                                });
                              }
                            },
                            style: FilledButton.styleFrom(
                              backgroundColor: cs.primary,
                              foregroundColor: cs.onPrimary,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12)),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 12),
                              textStyle: const TextStyle(
                                  fontSize: 14, fontWeight: FontWeight.w900),
                            ),
                            child: Text(saving ? '처리 중...' : '확인'),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ─────────────────────────────────────────
  // ✅ 주행
  // ─────────────────────────────────────────

  Future<void> _startEntryDriving() async {
    await _runPrimary(() async {
      if (_type != PlateType.parkingRequests) {
        _showWarningSafe('현재 상태에서는 입차 주행 시작이 불가능합니다.');
        return;
      }

      final userName = context.read<UserState>().name;
      final selectedBy = (_plate.selectedBy ?? '').trim();
      if (_plate.isSelected == true &&
          selectedBy.isNotEmpty &&
          selectedBy != userName) {
        _showWarningSafe('다른 사용자가 이미 주행 중입니다. (선택자: $selectedBy)');
        return;
      }

      final repo = context.read<PlateRepository>();
      final movementPlate = context.read<MovementPlate>();
      final plateState = context.read<MinorPlateState>();
      final id = _plateDocId();

      try {
        // 1) 주행 시작(선점)
        await repo.recordWhoPlateClick(
          id,
          true,
          selectedBy: userName,
          area: _plate.area,
        );

        // 로컬 즉시 반영(취소 권한 판단용)
        if (mounted) {
          setState(() {
            _plate = _plate.copyWith(
              isSelected: true,
              selectedBy: userName,
            );
          });
        }

        // 2) 블로킹 다이얼로그 (완료/취소)
        final canCancel = ((_plate.selectedBy ?? '').trim() == userName);
        final result = await _showDrivingBlockingDialog(
          message: '입차 주행 중입니다.',
          canCancel: canCancel,
          cancelDisabledHint: '선점자만 주행 취소가 가능합니다.',
          onComplete: () async {
            // ✅ 수정안 핵심:
            // - 여기서는 "완료" 버튼이 다이얼로그를 닫는 역할만 수행
            // - 실제 setParkingCompleted(location 삽입)는 다이얼로그 종료 후,
            //   중앙 "주차 구역 선택" 다이얼로그에서 수행
          },
          onCancel: () async {
            // ✅ 취소 권한 제한(2중 방어)
            final currentSelectedBy = (_plate.selectedBy ?? '').trim();
            if (currentSelectedBy != userName) {
              throw StateError('권한 없음: 선점자만 취소 가능');
            }

            await repo.recordWhoPlateClick(
              id,
              false,
              area: _plate.area,
            );

            await _logDrivingCancel(
              plateId: id,
              phase: '입차',
              userName: userName,
            );

            // 로컬/상태 즉시 반영
            final updated = _plate.copyWith(isSelected: false, selectedBy: null);
            if (mounted) setState(() => _plate = updated);
            try {
              await plateState.minorUpdatePlateLocally(
                PlateType.parkingRequests,
                updated,
              );
            } catch (_) {}

            try {
              showSuccessSnackbar(context, '주행이 취소되었습니다.');
            } catch (_) {}
          },
        );

        if (result == _DrivingResult.completed) {
          if (!mounted) return;

          // ✅ 주행 완료 후: 중앙 주차 구역 선택(캐시 기반)
          final area = _resolveAreaForCache();
          final picked = await _showParkingLocationPickerDialog(
            plateNumber: _plate.plateNumber,
            area: area,
            onConfirm: (pickedLocation) async {
              await movementPlate.setParkingCompleted(
                _plate.plateNumber,
                area,
                pickedLocation,
              );
            },
          );

          // 취소 시: 주행 상태 유지(사용자가 “주행 계속”으로 다시 정리 가능)
          if (picked == null || picked.trim().isEmpty) {
            showSelectedSnackbar(context, '주차 구역 선택이 취소되었습니다. (주행 상태 유지)');
            return;
          }

          // 성공: 시트 닫기
          if (!mounted) return;
          Navigator.pop(context);
          return;
        }

        if (result == _DrivingResult.cancelled) {
          // 시트는 유지
          return;
        }

        // 실패 시 선점 해제(잠김 방지)
        try {
          await repo.recordWhoPlateClick(
            id,
            false,
            area: _plate.area,
          );
        } catch (_) {}
      } on FirebaseException catch (e) {
        _showWarningSafe('입차 주행 시작 실패: ${e.message ?? e.code}');
      } catch (e) {
        _showWarningSafe('입차 주행 시작 실패: $e');
      }
    });
  }

  Future<void> _startDepartureDriving() async {
    await _runPrimary(() async {
      if (_type != PlateType.departureRequests) {
        _showWarningSafe('현재 상태에서는 출차 주행 시작이 불가능합니다.');
        return;
      }

      final userName = context.read<UserState>().name;
      final selectedBy = (_plate.selectedBy ?? '').trim();
      if (_plate.isSelected == true &&
          selectedBy.isNotEmpty &&
          selectedBy != userName) {
        _showWarningSafe('다른 사용자가 이미 주행 중입니다. (선택자: $selectedBy)');
        return;
      }

      final repo = context.read<PlateRepository>();
      final movementPlate = context.read<MovementPlate>();
      final plateState = context.read<MinorPlateState>();
      final id = _plateDocId();

      try {
        await repo.recordWhoPlateClick(
          id,
          true,
          selectedBy: userName,
          area: _plate.area,
        );

        if (mounted) {
          setState(() {
            _plate = _plate.copyWith(
              isSelected: true,
              selectedBy: userName,
            );
          });
        }

        final canCancel = ((_plate.selectedBy ?? '').trim() == userName);
        final result = await _showDrivingBlockingDialog(
          message: '출차 주행 중입니다.',
          canCancel: canCancel,
          cancelDisabledHint: '선점자만 주행 취소가 가능합니다.',
          onComplete: () async {
            await movementPlate.setDepartureCompleted(_plate);
          },
          onCancel: () async {
            final currentSelectedBy = (_plate.selectedBy ?? '').trim();
            if (currentSelectedBy != userName) {
              throw StateError('권한 없음: 선점자만 취소 가능');
            }

            await repo.recordWhoPlateClick(
              id,
              false,
              area: _plate.area,
            );

            await _logDrivingCancel(
              plateId: id,
              phase: '출차',
              userName: userName,
            );

            final updated = _plate.copyWith(isSelected: false, selectedBy: null);
            if (mounted) setState(() => _plate = updated);
            try {
              await plateState.minorUpdatePlateLocally(
                PlateType.departureRequests,
                updated,
              );
            } catch (_) {}

            try {
              showSuccessSnackbar(context, '주행이 취소되었습니다.');
            } catch (_) {}
          },
        );

        if (result == _DrivingResult.completed) {
          if (!mounted) return;
          Navigator.pop(context);
          return;
        }

        if (result == _DrivingResult.cancelled) {
          return;
        }

        try {
          await repo.recordWhoPlateClick(
            id,
            false,
            area: _plate.area,
          );
        } catch (_) {}
      } on FirebaseException catch (e) {
        _showWarningSafe('출차 주행 시작 실패: ${e.message ?? e.code}');
      } catch (e) {
        _showWarningSafe('출차 주행 시작 실패: $e');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final rootContext = Navigator.of(context, rootNavigator: true).context;

    final isLocked = _plate.isLockedFee == true;
    final lockedFee = _plate.lockedFeeAmount;
    final paymentMethod = (_plate.paymentMethod ?? '').trim();
    final billingType = (_plate.billingType ?? '').trim();
    final location =
    (_plate.location).trim().isEmpty ? '미지정' : _plate.location.trim();

    IconData primaryIcon = Icons.local_shipping_outlined;
    String primaryTitle = '출차 요청으로 이동';
    String primarySubtitle = '차량을 출차 요청 상태로 전환합니다.';
    Future<void> Function() primaryOnPressed = () async {
      await _runPrimary(() async {
        if (_needsBilling) {
          if (_isFreeBilling) {
            final ok = await _autoPrebillFreeIfNeeded();
            if (!ok) return;
            await _goDepartureRequested();
            return;
          }

          if (_overrideActive) {
            _resetOverride();

            final choice = await _showDepartureOverrideDialog();
            if (!mounted) return;

            if (choice == _DepartureOverrideChoice.proceed) {
              await _goDepartureRequested();
              return;
            }

            if (choice == _DepartureOverrideChoice.goBilling) {
              await _triggerBillingRequiredAttention(
                message: '정산을 진행해주세요. 정산 후 출차 요청으로 이동할 수 있습니다.',
              );
              return;
            }

            return;
          }

          _armOverride();
          await _triggerBillingRequiredAttention(
            message: '정산이 필요합니다. 먼저 정산을 진행하세요.\n'
                '정산 없이 출차 요청이 필요하면, 출차 요청 버튼을 한 번 더 누르세요.',
          );
          return;
        }

        _resetOverride();
        await _goDepartureRequested();
      });
    };

    if (_type == PlateType.parkingRequests) {
      primaryIcon = Icons.play_circle_fill;
      primaryTitle = _isMyDriving ? '입차 주행 계속' : '입차 주행 시작';
      primarySubtitle = _isMyDriving
          ? '이전에 시작된 주행 상태가 유지되었습니다. 완료 또는 취소로 정리하세요.'
          : '주행 중으로 전환 후, 완료 시 입차 완료로 변경됩니다.';
      primaryOnPressed = _startEntryDriving;
    } else if (_type == PlateType.departureRequests) {
      primaryIcon = Icons.play_circle_fill;
      primaryTitle = _isMyDriving ? '출차 주행 계속' : '출차 주행 시작';
      primarySubtitle = _isMyDriving
          ? '이전에 시작된 주행 상태가 유지되었습니다. 완료 또는 취소로 정리하세요.'
          : '주행 중으로 전환 후, 완료 시 출차 완료로 변경됩니다.';
      primaryOnPressed = _startDepartureDriving;
    }

    return SafeArea(
      top: false,
      child: Container(
        decoration: BoxDecoration(
          color: cs.surface,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          border: Border.all(color: _BrandTone.border(cs)),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
              child: Column(
                children: [
                  Center(
                    child: Container(
                      width: 44,
                      height: 4,
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: cs.outlineVariant.withOpacity(0.75),
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                  _SheetTitleRow(
                    title: '입차 완료 상태 처리',
                    icon: Icons.settings,
                    cs: cs,
                  ),
                  const SizedBox(height: 12),
                ],
              ),
            ),
            Expanded(
              child: AnimatedBuilder(
                animation: _attentionPulse,
                builder: (context, _) {
                  final attention = _attentionPulse.value;

                  final shakeDx = math.sin(_attentionCtrl.value * math.pi * 10) *
                      (1 - _attentionCtrl.value) *
                      6;
                  final scale = 1 + (attention * 0.012);

                  return ListView(
                    controller: _scrollController,
                    padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                    children: [
                      Transform.translate(
                        offset: Offset(_needsBilling ? shakeDx : 0, 0),
                        child: Transform.scale(
                          scale: _needsBilling ? scale : 1,
                          child: _PlateSummaryCard(
                            cs: cs,
                            plateNumber: widget.plateNumber,
                            area: _plate.area,
                            location: location,
                            billingType: billingType,
                            isLocked: isLocked,
                            lockedFee: lockedFee,
                            paymentMethod: paymentMethod,
                            attention: _needsBilling ? attention : 0,
                          ),
                        ),
                      ),
                      const SizedBox(height: 14),

                      _SectionCard(
                        cs: cs,
                        title: '핵심 작업',
                        subtitle: '자주 사용하는 기능을 상단에 배치했습니다.',
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Expanded(
                                  child: _ActionTileButton(
                                    cs: cs,
                                    icon: Icons.receipt_long,
                                    title: '정산',
                                    subtitle: '사전 정산',
                                    tone: _ActionTone.positive,
                                    attention: _needsBilling ? attention : 0,
                                    onTap: () async {
                                      final userName =
                                          context.read<UserState>().name;
                                      final repo =
                                      context.read<PlateRepository>();
                                      final plateState =
                                      context.read<MinorPlateState>();
                                      final firestore =
                                          FirebaseFirestore.instance;

                                      final bt =
                                      (_plate.billingType ?? '').trim();
                                      if (bt.isEmpty) {
                                        _showWarningSafe(
                                            '정산 타입이 지정되지 않아 사전 정산이 불가능합니다.');
                                        return;
                                      }

                                      final now = DateTime.now();
                                      final currentTime = now
                                          .toUtc()
                                          .millisecondsSinceEpoch ~/
                                          1000;
                                      final entryTime = _plate.requestTime
                                          .toUtc()
                                          .millisecondsSinceEpoch ~/
                                          1000;

                                      final result =
                                      await showOnTapBillingBottomSheet(
                                        context: context,
                                        entryTimeInSeconds: entryTime,
                                        currentTimeInSeconds: currentTime,
                                        basicStandard:
                                        _plate.basicStandard ?? 0,
                                        basicAmount: _plate.basicAmount ?? 0,
                                        addStandard: _plate.addStandard ?? 0,
                                        addAmount: _plate.addAmount ?? 0,
                                        billingType:
                                        _plate.billingType ?? '변동',
                                        regularAmount: _plate.regularAmount,
                                        regularDurationHours:
                                        _plate.regularDurationHours,
                                      );
                                      if (result == null) return;

                                      final updatedPlate = _plate.copyWith(
                                        isLockedFee: true,
                                        lockedAtTimeInSeconds: currentTime,
                                        lockedFeeAmount: result.lockedFee,
                                        paymentMethod: result.paymentMethod,
                                      );

                                      try {
                                        await repo.addOrUpdatePlate(
                                            _plate.id, updatedPlate);
                                        _reportDbSafe(
                                          area: _plate.area,
                                          action: 'write',
                                          source:
                                          'parkingCompletedStatus.prebill.repo.addOrUpdatePlate',
                                          n: 1,
                                        );

                                        await plateState.minorUpdatePlateLocally(
                                          PlateType.parkingCompleted,
                                          updatedPlate,
                                        );

                                        final log = {
                                          'action': '사전 정산',
                                          'performedBy': userName,
                                          'timestamp': now.toIso8601String(),
                                          'lockedFee': result.lockedFee,
                                          'paymentMethod': result.paymentMethod,
                                          if (result.reason != null &&
                                              result.reason!
                                                  .trim()
                                                  .isNotEmpty)
                                            'reason': result.reason!.trim(),
                                        };

                                        await firestore
                                            .collection('plates')
                                            .doc(_plate.id)
                                            .update({
                                          'logs': FieldValue.arrayUnion([log]),
                                        });
                                        _reportDbSafe(
                                          area: _plate.area,
                                          action: 'write',
                                          source:
                                          'parkingCompletedStatus.prebill.plates.update.logs.arrayUnion',
                                          n: 1,
                                        );

                                        if (!mounted) return;

                                        setState(() => _plate = updatedPlate);
                                        _resetOverride();

                                        showSuccessSnackbar(
                                          context,
                                          '사전 정산 완료: ₩${result.lockedFee} (${result.paymentMethod})',
                                        );
                                      } catch (e) {
                                        if (!mounted) return;
                                        _showWarningSafe(
                                            '사전 정산 중 오류가 발생했습니다: $e');
                                      }
                                    },
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: _ActionTileButton(
                                    cs: cs,
                                    icon: Icons.lock_open,
                                    title: '정산 취소',
                                    subtitle: isLocked ? '잠금 해제' : '잠금 아님',
                                    tone: _ActionTone.neutral,
                                    badgeText: isLocked ? '잠김' : '비잠김',
                                    onTap: () async {
                                      final userName =
                                          context.read<UserState>().name;
                                      final repo =
                                      context.read<PlateRepository>();
                                      final plateState =
                                      context.read<MinorPlateState>();
                                      final firestore =
                                          FirebaseFirestore.instance;

                                      if (_plate.isLockedFee != true) {
                                        _showWarningSafe(
                                            '현재 사전 정산 상태가 아닙니다.');
                                        return;
                                      }

                                      final confirm = await showDialog<bool>(
                                        context: context,
                                        builder: (_) =>
                                        const ConfirmCancelFeeDialog(),
                                      );
                                      if (confirm != true) return;

                                      final now = DateTime.now();
                                      final updatedPlate = _plate.copyWith(
                                        isLockedFee: false,
                                        lockedAtTimeInSeconds: null,
                                        lockedFeeAmount: null,
                                        paymentMethod: null,
                                      );

                                      try {
                                        await repo.addOrUpdatePlate(
                                            _plate.id, updatedPlate);
                                        _reportDbSafe(
                                          area: _plate.area,
                                          action: 'write',
                                          source:
                                          'parkingCompletedStatus.unlock.repo.addOrUpdatePlate',
                                          n: 1,
                                        );

                                        await plateState.minorUpdatePlateLocally(
                                          PlateType.parkingCompleted,
                                          updatedPlate,
                                        );

                                        final cancelLog = {
                                          'action': '사전 정산 취소',
                                          'performedBy': userName,
                                          'timestamp': now.toIso8601String(),
                                        };

                                        await firestore
                                            .collection('plates')
                                            .doc(_plate.id)
                                            .update({
                                          'logs': FieldValue.arrayUnion(
                                              [cancelLog]),
                                        });
                                        _reportDbSafe(
                                          area: _plate.area,
                                          action: 'write',
                                          source:
                                          'parkingCompletedStatus.unlock.plates.update.logs.arrayUnion',
                                          n: 1,
                                        );

                                        if (!mounted) return;

                                        setState(() => _plate = updatedPlate);
                                        _resetOverride();

                                        showSuccessSnackbar(
                                          context,
                                          '사전 정산이 취소되었습니다.',
                                        );
                                      } catch (e) {
                                        if (!mounted) return;
                                        _showWarningSafe(
                                            '정산 취소 중 오류가 발생했습니다: $e');
                                      }
                                    },
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            _PrimaryCtaButton(
                              cs: cs,
                              icon: primaryIcon,
                              title: primaryTitle,
                              subtitle: primarySubtitle,
                              onPressed: primaryOnPressed,
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 14),

                      _SectionCard(
                        cs: cs,
                        title: '기타',
                        subtitle: '로그 확인, 정보 수정, 상태 되돌리기, 삭제 등',
                        child: Column(
                          children: [
                            GridView.count(
                              crossAxisCount: 2,
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              crossAxisSpacing: 12,
                              mainAxisSpacing: 12,
                              childAspectRatio: 2.6,
                              children: [
                                _SecondaryActionButton(
                                  cs: cs,
                                  icon: Icons.history,
                                  label: '로그 확인',
                                  onPressed: () {
                                    Navigator.pop(context);
                                    Navigator.push(
                                      rootContext,
                                      MaterialPageRoute(
                                        builder: (_) => LogViewerBottomSheet(
                                          initialPlateNumber: widget.plateNumber,
                                          division: widget.division,
                                          area: widget.area,
                                          requestTime: _plate.requestTime,
                                        ),
                                      ),
                                    );
                                  },
                                ),
                                _SecondaryActionButton(
                                  cs: cs,
                                  icon: Icons.edit_note_outlined,
                                  label: '정보 수정',
                                  onPressed: () {
                                    Navigator.pop(context);
                                    Navigator.push(
                                      rootContext,
                                      MaterialPageRoute(
                                        builder: (_) => MinorModifyPlateScreen(
                                          plate: _plate,
                                          collectionKey: PlateType.parkingCompleted,
                                        ),
                                      ),
                                    );
                                  },
                                ),

                                // ✅ onRequestEntry 사용(죽은 파라미터 제거)
                                if (_type == PlateType.parkingCompleted)
                                  _SecondaryActionButton(
                                    cs: cs,
                                    icon: Icons.undo,
                                    label: '입차 요청으로',
                                    onPressed: () async {
                                      try {
                                        await widget.onRequestEntry();
                                        if (!mounted) return;
                                        showSuccessSnackbar(context, '입차 요청으로 되돌렸습니다.');
                                        Navigator.pop(context);
                                      } catch (e) {
                                        if (!mounted) return;
                                        showFailedSnackbar(context, '처리 실패: $e');
                                      }
                                    },
                                  ),

                                _DangerActionButton(
                                  cs: cs,
                                  icon: Icons.delete_forever,
                                  label: '삭제',
                                  onPressed: () {
                                    Navigator.pop(context);
                                    widget.onDelete();
                                  },
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DrivingBlockingDialog extends StatefulWidget {
  const _DrivingBlockingDialog({
    required this.message,
    required this.canCancel,
    required this.cancelDisabledHint,
    required this.onComplete,
    required this.onCancel,
  });

  final String message;
  final bool canCancel;
  final String cancelDisabledHint;

  final Future<_DrivingResult> Function() onComplete;
  final Future<_DrivingResult> Function() onCancel;

  @override
  State<_DrivingBlockingDialog> createState() => _DrivingBlockingDialogState();
}

class _DrivingBlockingDialogState extends State<_DrivingBlockingDialog> {
  bool _busy = false;

  Future<void> _run(Future<_DrivingResult> Function() fn) async {
    if (_busy) return;
    setState(() => _busy = true);
    final r = await fn();
    if (!mounted) return;
    Navigator.of(context, rootNavigator: true).pop(r);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
      backgroundColor: cs.surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: _BrandTone.border(cs)),
      ),
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              width: 30,
              height: 30,
              child: CircularProgressIndicator(
                strokeWidth: 3,
                valueColor: AlwaysStoppedAnimation<Color>(
                  _busy ? cs.onSurfaceVariant : cs.primary,
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              widget.message,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w900,
                color: cs.onSurface,
              ),
            ),
            if (!widget.canCancel) ...[
              const SizedBox(height: 10),
              Text(
                widget.cancelDisabledHint,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: cs.error,
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
            const SizedBox(height: 14),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: (_busy || !widget.canCancel)
                        ? null
                        : () => _run(widget.onCancel),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                          vertical: 14, horizontal: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                      side: BorderSide(color: _BrandTone.border(cs)),
                      textStyle: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w900),
                      foregroundColor: cs.onSurface,
                    ),
                    child: Text(_busy ? '처리 중...' : '주행 취소'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: FilledButton(
                    onPressed: _busy ? null : () => _run(widget.onComplete),
                    style: FilledButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                          vertical: 14, horizontal: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                      textStyle: const TextStyle(
                          fontSize: 16, fontWeight: FontWeight.w900),
                      backgroundColor: cs.primary,
                      foregroundColor: cs.onPrimary,
                    ),
                    child: Text(_busy ? '처리 중...' : '주행 완료'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _SheetTitleRow extends StatelessWidget {
  final String title;
  final IconData icon;
  final ColorScheme cs;

  const _SheetTitleRow({
    required this.title,
    required this.icon,
    required this.cs,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, color: cs.primary),
        const SizedBox(width: 8),
        Text(
          title,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w900,
            color: cs.onSurface,
          ),
        ),
      ],
    );
  }
}

class _PlateSummaryCard extends StatelessWidget {
  final ColorScheme cs;

  final String plateNumber;
  final String area;
  final String location;
  final String billingType;
  final bool isLocked;
  final int? lockedFee;
  final String paymentMethod;

  final double attention;

  const _PlateSummaryCard({
    required this.cs,
    required this.plateNumber,
    required this.area,
    required this.location,
    required this.billingType,
    required this.isLocked,
    required this.lockedFee,
    required this.paymentMethod,
    this.attention = 0,
  });

  @override
  Widget build(BuildContext context) {
    final badgeColor = isLocked ? _BrandTone.ok(cs) : cs.onSurfaceVariant;
    final badgeText = isLocked ? '사전정산 잠김' : '사전정산 없음';

    final feeText =
    (isLocked && lockedFee != null) ? '₩$lockedFee${paymentMethod.isNotEmpty ? " ($paymentMethod)" : ""}' : '—';

    final billingText = billingType.isNotEmpty ? billingType : '미지정';

    final borderColor = Color.lerp(
      _BrandTone.border(cs),
      cs.error,
      (attention * 0.75).clamp(0, 1),
    )!;

    final bgColor = Color.lerp(
      cs.surfaceContainerLow,
      cs.errorContainer.withOpacity(0.40),
      (attention * 0.55).clamp(0, 1),
    )!;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: bgColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderColor, width: 1.2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  plateNumber,
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 0.2,
                    color: cs.onSurface,
                  ),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: badgeColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: badgeColor.withOpacity(0.35)),
                ),
                child: Text(
                  badgeText,
                  style: TextStyle(
                    color: badgeColor,
                    fontWeight: FontWeight.w800,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _InfoLine(cs: cs, label: '지역', value: area)),
              const SizedBox(width: 12),
              Expanded(child: _InfoLine(cs: cs, label: '위치', value: location)),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(child: _InfoLine(cs: cs, label: '정산 타입', value: billingText)),
              const SizedBox(width: 12),
              Expanded(child: _InfoLine(cs: cs, label: '잠금 금액', value: feeText)),
            ],
          ),
        ],
      ),
    );
  }
}

class _InfoLine extends StatelessWidget {
  final ColorScheme cs;
  final String label;
  final String value;

  const _InfoLine({
    required this.cs,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    final v = value.trim().isEmpty ? '—' : value.trim();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: TextStyle(
            color: cs.onSurfaceVariant,
            fontSize: 12,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          v,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: cs.onSurface,
            fontSize: 14,
            fontWeight: FontWeight.w800,
          ),
        ),
      ],
    );
  }
}

class _SectionCard extends StatelessWidget {
  final ColorScheme cs;
  final String title;
  final String subtitle;
  final Widget child;

  const _SectionCard({
    required this.cs,
    required this.title,
    required this.subtitle,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: cs.surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _BrandTone.border(cs)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16, color: cs.onSurface),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: TextStyle(color: cs.onSurfaceVariant, fontSize: 12),
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

enum _ActionTone { positive, neutral }

class _ActionTileButton extends StatelessWidget {
  final ColorScheme cs;

  final IconData icon;
  final String title;
  final String subtitle;
  final _ActionTone tone;
  final String? badgeText;
  final VoidCallback onTap;
  final double attention;

  const _ActionTileButton({
    required this.cs,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.tone,
    required this.onTap,
    this.badgeText,
    this.attention = 0,
  });

  @override
  Widget build(BuildContext context) {
    final Color base = (tone == _ActionTone.positive) ? _BrandTone.ok(cs) : cs.onSurfaceVariant;
    final Color bg = (tone == _ActionTone.positive) ? _BrandTone.okBg(cs).withOpacity(0.55) : cs.surfaceContainerLow;
    final Color border = _BrandTone.border(cs);

    final Color attentionBorder = Color.lerp(border, cs.error, (attention * 0.75).clamp(0, 1))!;
    final Color attentionBg = Color.lerp(bg, cs.errorContainer.withOpacity(0.35), (attention * 0.55).clamp(0, 1))!;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Ink(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: attentionBg,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: attentionBorder, width: 1.2),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(icon, color: base),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      title,
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 15,
                        color: cs.onSurface,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  if (badgeText != null) ...[
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: base.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: base.withOpacity(0.25)),
                      ),
                      child: Text(
                        badgeText!,
                        style: TextStyle(
                          color: base,
                          fontWeight: FontWeight.w900,
                          fontSize: 11,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
              const SizedBox(height: 8),
              Text(
                subtitle,
                style: TextStyle(
                  color: cs.onSurfaceVariant,
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PrimaryCtaButton extends StatelessWidget {
  final ColorScheme cs;

  final IconData icon;
  final String title;
  final String subtitle;
  final Future<void> Function() onPressed;

  const _PrimaryCtaButton({
    required this.cs,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: FilledButton(
        style: FilledButton.styleFrom(
          backgroundColor: cs.primary,
          foregroundColor: cs.onPrimary,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 14),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
        ),
        onPressed: () async => onPressed(),
        child: Row(
          children: [
            Icon(icon),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: cs.onPrimary.withOpacity(0.90),
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right),
          ],
        ),
      ),
    );
  }
}

class _SecondaryActionButton extends StatelessWidget {
  final ColorScheme cs;
  final IconData icon;
  final String label;
  final VoidCallback onPressed;

  const _SecondaryActionButton({
    required this.cs,
    required this.icon,
    required this.label,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      icon: Icon(icon, size: 18, color: cs.onSurface),
      label: Text(
        label,
        style: TextStyle(fontWeight: FontWeight.w900, color: cs.onSurface),
        textAlign: TextAlign.center,
      ),
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        minimumSize: const Size(double.infinity, 46),
        side: BorderSide(color: _BrandTone.border(cs)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        backgroundColor: cs.surfaceContainerLow,
      ),
    );
  }
}

class _DangerActionButton extends StatelessWidget {
  final ColorScheme cs;
  final IconData icon;
  final String label;
  final VoidCallback onPressed;

  const _DangerActionButton({
    required this.cs,
    required this.icon,
    required this.label,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      icon: Icon(icon, color: cs.error),
      label: Text(
        label,
        style: TextStyle(color: cs.error, fontWeight: FontWeight.w900),
      ),
      onPressed: onPressed,
      style: OutlinedButton.styleFrom(
        minimumSize: const Size(double.infinity, 48),
        side: BorderSide(color: cs.error.withOpacity(0.55)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        backgroundColor: cs.errorContainer.withOpacity(0.35),
      ),
    );
  }
}

void _reportDbSafe({
  required String area,
  required String action,
  required String source,
  int n = 1,
}) {
  try {
    /*UsageReporter.instance.report(
      area: area.trim(),
      action: action,
      n: n,
      source: source,
    );*/
  } catch (_) {}
}

Future<void> handleEntryParkingRequest(
    BuildContext context,
    String plateNumber,
    String area,
    ) async {
  final movementPlate = context.read<MovementPlate>();
  await movementPlate.goBackToParkingRequest(
    fromType: PlateType.parkingCompleted,
    plateNumber: plateNumber,
    area: area,
    newLocation: "미지정",
  );
}
