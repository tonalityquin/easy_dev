import 'package:flutter/material.dart';

class MinorInputAnimatedActionButton extends StatefulWidget {
  final bool isLoading;
  final bool isLocationSelected;
  final Future<void> Function() onPressed;

  const MinorInputAnimatedActionButton({
    super.key,
    required this.isLoading,
    required this.isLocationSelected,
    required this.onPressed,
  });

  @override
  State<MinorInputAnimatedActionButton> createState() => _MinorInputAnimatedActionButtonState();
}

class _MinorInputAnimatedActionButtonState extends State<MinorInputAnimatedActionButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
      lowerBound: 0.95,
      upperBound: 1.0,
    );

    _scaleAnimation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeOut,
    );
  }

  Future<void> _handleTap() async {
    await _controller.reverse();
    await _controller.forward();
    await widget.onPressed();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    final bool isLoading = widget.isLoading;
    final bool isLocationSelected = widget.isLocationSelected;

    // - 위치 선택 시: "입차 완료"
    // - 위치 미선택 시: "입차 요청"
    final String label = isLocationSelected ? '입차 완료' : '입차 요청';

    // 위치 미선택이어도 제출 가능, 로딩 중만 비활성
    final bool isDisabled = isLoading;

    // ✅ 상태별 토큰 매핑
    final Color bg = isLocationSelected ? cs.primaryContainer : cs.surface;
    final Color fg = isLocationSelected ? cs.onPrimaryContainer : cs.onSurface;
    final Color border = isLocationSelected ? cs.primary : cs.outlineVariant;

    final Color disabledBg = bg.withOpacity(0.55);
    final Color disabledFg = fg.withOpacity(0.55);

    final Color spinnerColor = isLocationSelected ? cs.onPrimaryContainer : cs.primary;

    return ScaleTransition(
      scale: _scaleAnimation,
      child: ElevatedButton(
        onPressed: isDisabled ? null : _handleTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: bg,
          foregroundColor: fg,
          disabledBackgroundColor: disabledBg,
          disabledForegroundColor: disabledFg,
          elevation: 0,
          padding: const EdgeInsets.symmetric(vertical: 16.0, horizontal: 80),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(color: border, width: 1.5),
          ),
        ),
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          transitionBuilder: (Widget child, Animation<double> animation) {
            return ScaleTransition(scale: animation, child: child);
          },
          child: isLoading
              ? SizedBox(
            key: const ValueKey('loading'),
            width: 20,
            height: 20,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(spinnerColor),
            ),
          )
              : Text(
            label,
            key: const ValueKey('buttonText'),
            style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }
}
