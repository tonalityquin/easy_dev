// lib/screens/type_pages/parking_completed_pages/widgets/parking_status_page.dart
import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../states/location/location_state.dart';
import '../../../../states/area/area_state.dart';
// import '../../../../utils/usage_reporter.dart';;

class ParkingStatusPage extends StatefulWidget {
  final bool isLocked;

  const ParkingStatusPage({super.key, required this.isLocked});

  @override
  State<ParkingStatusPage> createState() => _ParkingStatusPageState();
}

class _ParkingStatusPageState extends State<ParkingStatusPage> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  int _occupiedCount = 0; // 영역 전체의 주차 완료 총합
  bool _isCountLoading = true; // 총합 집계 로딩 상태

  // 🔒 UI 표시 시점에만 1회 집계하도록 제어
  bool _didCountRun = false;

  // Area 변경 감지용
  String? _lastArea;

  // 에러 상태 플래그
  bool _hadError = false;

  @override
  void initState() {
    super.initState();
    // 첫 프레임 이후에 라우트 가시성 확인 → 표시 중일 때만 집계
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybeRunCount());
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // 라우트 바인딩이 늦게 잡히는 경우를 대비해 한 번 더 시도
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybeRunCount());
  }

  void _maybeRunCount() {
    if (_didCountRun) return;
    // 현재 라우트가 실제로 화면에 표시될 때만 실행
    final route = ModalRoute.of(context);
    final isVisible = route == null ? true : (route.isCurrent || route.isActive);
    if (!isVisible) return;
    _didCountRun = true;
    _runAggregateCount();
  }

  Future<void> _runAggregateCount() async {
    if (!mounted) return;

    final area = context.read<AreaState>().currentArea.trim();
    _lastArea = area; // 최신 area 기억

    setState(() {
      _isCountLoading = true;
      _hadError = false;
    });

    try {
      final aggQuery = _firestore
          .collection('plates')
          .where('area', isEqualTo: area)
          .where('type', isEqualTo: 'parking_completed')
          .count();

      final snap = await aggQuery.get();
      final cnt = (snap.count ?? 0);

      try {
        /*await UsageReporter.instance.report(
          area: area,
          action: 'read', // 읽기
          n: 1, // ← 고정(집계 1회당 read 1회)
          source: 'parkingStatus.count.query(parking_completed).aggregate',
        );*/
      } catch (_) {
        // 계측 실패는 UX에 영향 없음
      }

      if (!mounted) return;
      setState(() {
        _occupiedCount = cnt;
        _isCountLoading = false;
        _hadError = false;
      });
    } catch (e) {
      try {
        /*await UsageReporter.instance.report(
          area: context.read<AreaState>().currentArea.trim(),
          action: 'read',
          n: 1, // ← 실패여도 1회 시도로 고정
          source: 'parkingStatus.count.query(parking_completed).aggregate.error',
        );*/
      } catch (_) {}

      if (!mounted) return;
      setState(() {
        _occupiedCount = 0;
        _isCountLoading = false;
        _hadError = true; // 에러 플래그 ON
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    // 빌드 후에도 가시성 변화가 있으면 한 번 더 시도(이미 실행되었으면 무시됨)
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybeRunCount());

    // Area 변경 감지 → 재집계 트리거
    final currentArea = context.select<AreaState, String>((s) => s.currentArea.trim());
    if (_lastArea != null && _lastArea != currentArea) {
      // 같은 위젯 인스턴스지만 area가 바뀐 경우에 한해 다시 1회 돌리도록 플래그를 내리고 트리거
      _didCountRun = false;
      _lastArea = currentArea;
      WidgetsBinding.instance.addPostFrameCallback((_) => _maybeRunCount());
    }

    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          Consumer<LocationState>(
            builder: (context, locationState, _) {
              // locations 로딩(용량 합산용) 또는 총합 집계 로딩 중이면 스피너
              if (locationState.isLoading || _isCountLoading) {
                return const Center(child: CircularProgressIndicator());
              }

              // capacity 합계는 로컬 state로 계산 (요청: 유지)
              final totalCapacity =
              locationState.locations.fold<int>(0, (sum, l) => sum + l.capacity);
              final occupiedCount = _occupiedCount;

              final double usageRatio =
              totalCapacity == 0 ? 0 : occupiedCount / totalCapacity;
              final String usagePercent = (usageRatio * 100).toStringAsFixed(1);

              if (_hadError) {
                // 에러 UI: 간단한 재시도 버튼 제공
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.warning_amber, size: 40, color: Colors.redAccent),
                        const SizedBox(height: 12),
                        const Text(
                          '현황 집계 중 오류가 발생했습니다.',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          '영역: $currentArea',
                          style: const TextStyle(color: Colors.black54),
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton.icon(
                          onPressed: () {
                            _didCountRun = false; // 다시 1회만 돌도록
                            _runAggregateCount();
                          },
                          icon: const Icon(Icons.refresh),
                          label: const Text('다시 집계'),
                        ),
                      ],
                    ),
                  ),
                );
              }

              // ------ 상단 영역: "디자인/텍스트 수정 금지" 요청 반영 ------
              return ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  const Text(
                    '📊 현재 주차 현황',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    '총 $totalCapacity대 중 $occupiedCount대 주차됨',
                    style: const TextStyle(fontSize: 16),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: usageRatio,
                    backgroundColor: Colors.grey[300],
                    valueColor: AlwaysStoppedAnimation<Color>(
                      usageRatio >= 0.8 ? Colors.red : Colors.blueAccent,
                    ),
                    minHeight: 8,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    '$usagePercent% 사용 중',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                    textAlign: TextAlign.center,
                  ),
                  // ------ 상단 영역 끝 (수정 없음) ------

                  const SizedBox(height: 24),

                  // ⬇️ 하단 자동 순환 카드: 한 화면에 한 장, 몇 초마다 다음 카드로 애니메이션
                  const _AutoCyclingReminderCards(),

                  const SizedBox(height: 12),
                ],
              );
            },
          ),
          if (widget.isLocked)
            Positioned.fill(
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: () {},
                child: const SizedBox.expand(),
              ),
            ),
        ],
      ),
    );
  }
}

/// 하단에 표시되는 자동 순환 카드 뷰
/// - 한 번에 한 카드만 표시
/// - [cycleInterval]마다 자동으로 다음 카드로 애니메이션
/// - 마지막까지 읽으면 다시 첫 카드로 순환
class _AutoCyclingReminderCards extends StatefulWidget {
  const _AutoCyclingReminderCards();

  @override
  State<_AutoCyclingReminderCards> createState() => _AutoCyclingReminderCardsState();
}

class _AutoCyclingReminderCardsState extends State<_AutoCyclingReminderCards> {
  // ✔ 2초 주기로 전환
  static const Duration cycleInterval = Duration(seconds: 2);
  static const Duration animDuration = Duration(milliseconds: 400);
  static const Curve animCurve = Curves.easeInOut;

  final PageController _pageController = PageController();
  Timer? _timer;
  int _currentIndex = 0;

  // 중앙 정렬 카드 컨텐츠 (업무 리마인더)
  static const List<_ReminderContent> _cards = [
    _ReminderContent(
      title: '주의사항',
      lines: [
        '• 보조 페이지는 꼭 잠그기',
        '• 업무와 관련 없는 행위는 피하기',
      ],
    ),
    _ReminderContent(
      title: '업무 시작 시',
      lines: [
        '• 업무 시작 전과 후 청결하게 청소하기',
        '• 유니폼, 무전기 등 점검하기',
      ],
    ),
    _ReminderContent(
      title: '업무 중',
      lines: [
        '• 지정된 위치에서 친절한 서비스 제공하기',
        '• 잠시 부재 중일 경우 꼭 보고하기',
      ],
    ),
    _ReminderContent(
      title: '사고 발생 시',
      lines: [
        '• 현장 및 지정 관리자에게 보고하기',
        '• 관리자의 메뉴얼을 준수하기',
      ],
    ),
    _ReminderContent(
      title: '컴플레인 발생 시',
      lines: [
        '• 컴플레인 당사자와의 다툼은 절대 피하기',
        '• 현장 관리자를 통해서 컴플레인 해결하기',
      ],
    ),
    _ReminderContent(
      title: '업무 종료',
      lines: [
        '• 휴게 및 퇴근 보고는 반드시 하기',
        '• 제공된 유니폼 정돈 및 청결하게 관리하기',
      ],
    ),
  ];

  @override
  void initState() {
    super.initState();
    _startAutoCycle();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pageController.dispose();
    super.dispose();
  }

  void _startAutoCycle() {
    _timer?.cancel();
    if (_cards.length <= 1) return; // 카드가 1장 이하이면 순환 불필요
    _timer = Timer.periodic(cycleInterval, (_) {
      if (!mounted) return;
      final next = (_currentIndex + 1) % _cards.length;
      _animateToPage(next);
    });
  }

  void _animateToPage(int index) {
    _currentIndex = index;
    if (!mounted) return;
    _pageController.animateToPage(
      index,
      duration: animDuration,
      curve: animCurve,
    );
    setState(() {}); // 현재 인덱스 반영(인디케이터 등 확장 시 대비)
  }

  @override
  Widget build(BuildContext context) {
    // ListView 안에 들어가므로 높이를 고정해 주어야 함
    return SizedBox(
      height: 170,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // 가운데 정렬로 한 카드씩만 보이게
          Align(
            alignment: Alignment.center,
            child: FractionallySizedBox(
              widthFactor: 0.98, // 좌우 여백 약간
              child: PageView.builder(
                controller: _pageController,
                physics: const NeverScrollableScrollPhysics(), // 스와이프 대신 자동 전환
                onPageChanged: (i) => _currentIndex = i,
                itemCount: _cards.length,
                itemBuilder: (context, index) {
                  final c = _cards[index];
                  return Center(
                    child: Card(
                      color: Colors.white, // 카드 배경 하얀색
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.center, // 중앙 정렬
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(Icons.fact_check, size: 18),
                                const SizedBox(width: 8),
                                Text(
                                  c.title,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ],
                            ),
                            const SizedBox(height: 12),
                            ...c.lines.map(
                                  (t) => Padding(
                                padding: const EdgeInsets.only(bottom: 6),
                                child: Text(
                                  t,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(fontSize: 14),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

          // (선택) 하단 점 인디케이터 - 중앙 정렬
          Positioned(
            bottom: 6,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: List.generate(_cards.length, (i) {
                final active = i == _currentIndex;
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: active ? 10 : 6,
                  height: 6,
                  decoration: BoxDecoration(
                    color: active ? Colors.black87 : Colors.black26,
                    borderRadius: BorderRadius.circular(3),
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }
}

class _ReminderContent {
  final String title;
  final List<String> lines;
  const _ReminderContent({required this.title, required this.lines});
}
