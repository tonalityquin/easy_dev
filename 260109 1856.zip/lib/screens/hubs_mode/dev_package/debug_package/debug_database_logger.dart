import 'dart:io';

import 'debug_api_logger.dart';

/// Compatibility wrapper.
///
/// Legacy callers previously wrote to a dedicated "database_log.txt" file via
/// [DebugDatabaseLogger]. The logging system has been unified so that **all**
/// error logs are written to the API logger (api_log.txt) only.
///
/// This class now delegates all operations to [DebugApiLogger].
@Deprecated('Use DebugApiLogger instead. DebugDatabaseLogger is kept for backward compatibility.')
class DebugDatabaseLogger {
  // ---- Singleton ----
  static final DebugDatabaseLogger _instance = DebugDatabaseLogger._internal();

  factory DebugDatabaseLogger() => _instance;

  DebugDatabaseLogger._internal();

  final DebugApiLogger _api = DebugApiLogger();

  Future<void> init() => _api.init();

  File? getLogFile() => _api.getLogFile();

  Future<void> log(Object? message, {String level = 'info', List<String>? tags}) {
    return _api.log(message, level: level, tags: tags);
  }

  Future<List<String>> readTailLines({int maxLines = 1500, int maxBytes = 1024 * 1024}) {
    return _api.readTailLines(maxLines: maxLines, maxBytes: maxBytes);
  }

  Future<List<String>> readAllLinesCombined() => _api.readAllLinesCombined();

  Future<List<File>> getAllLogFilesExisting({bool orderedOldestFirst = false}) {
    return _api.getAllLogFilesExisting(orderedOldestFirst: orderedOldestFirst);
  }

  Future<void> clearLog() => _api.clearLog();
}
